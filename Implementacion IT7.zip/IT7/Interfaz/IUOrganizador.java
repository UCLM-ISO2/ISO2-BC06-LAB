package Interfaz;

public class IUOrganizador {

	public void clickGenerarCertificado() {
		throw new UnsupportedOperationException();
	}
}