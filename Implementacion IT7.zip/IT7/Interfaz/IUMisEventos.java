package Interfaz;

public class IUMisEventos {

	public void apuntarse() {
		throw new UnsupportedOperationException();
	}

	public void desapuntarse() {
		throw new UnsupportedOperationException();
	}

	public void pedirCertificado() {
		throw new UnsupportedOperationException();
	}

	public void a�adirEventoCalendario(int aIdEvento) {
		throw new UnsupportedOperationException();
	}
}