package Interfaz;

public class IUAdministrarEncuestas {

	public void administrarEncuestas() {
		throw new UnsupportedOperationException();
	}
}