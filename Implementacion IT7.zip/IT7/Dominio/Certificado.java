package Dominio;

public class Certificado {
	private Cliente _cliente;
	private Evento _evento;
	private int _id;
	public Evento _unnamed_Evento_44;
	public Organizador _unnamed_Organizador_45;
	public Cliente _unnamed_Cliente_46;
}