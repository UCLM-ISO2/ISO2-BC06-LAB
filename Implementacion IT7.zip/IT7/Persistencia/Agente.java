package Persistencia;

public class Agente {
	private Agente _miInstancia;

	public Agente() {
		throw new UnsupportedOperationException();
	}

	public Agente getAgente() {
		throw new UnsupportedOperationException();
	}

	public int insert(String aSQL) {
		throw new UnsupportedOperationException();
	}

	public Vector<Object> select(String aSQL) {
		throw new UnsupportedOperationException();
	}

	public int update(String aSQL) {
		throw new UnsupportedOperationException();
	}

	public int delete(String aSQL) {
		throw new UnsupportedOperationException();
	}

	public void conectar() {
		throw new UnsupportedOperationException();
	}
}