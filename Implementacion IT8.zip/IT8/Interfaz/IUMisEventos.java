package Interfaz;

public class IUMisEventos {

	public void apuntarse() {
		throw new UnsupportedOperationException();
	}

	public void desapuntarse() {
		throw new UnsupportedOperationException();
	}

	public void pedirCertificado() {
		throw new UnsupportedOperationException();
	}

	public void añadirEventoCalendario(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void valorarEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}
}