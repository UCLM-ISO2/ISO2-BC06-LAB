package Dominio;

public class ControlConsulta {

	public void crearListadoAsistentes() {
		throw new UnsupportedOperationException();
	}

	public void crearListadoEventos(String aAlumno) {
		throw new UnsupportedOperationException();
	}

	public void crearListadoEventosOrg() {
		throw new UnsupportedOperationException();
	}

	public void consultarMediaAsis(evento aEvento) {
		throw new UnsupportedOperationException();
	}

	public void consultarFaltas(String aTipo) {
		throw new UnsupportedOperationException();
	}

	public void consultarSatisfaccion(evento aEvento) {
		throw new UnsupportedOperationException();
	}
}