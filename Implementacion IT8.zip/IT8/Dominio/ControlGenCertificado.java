package Dominio;

public class ControlGenCertificado {

	public void generarCertificado() {
		throw new UnsupportedOperationException();
	}
}