package Dominio;

public class ControlEncuestas {

	public void administrarEncuestas() {
		throw new UnsupportedOperationException();
	}
}