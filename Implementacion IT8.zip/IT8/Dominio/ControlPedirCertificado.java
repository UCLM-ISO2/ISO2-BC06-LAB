package Dominio;

public class ControlPedirCertificado {

	public void pedirCertificado(int aIdCertificado) {
		throw new UnsupportedOperationException();
	}
}