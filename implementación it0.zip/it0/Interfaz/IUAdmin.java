package Interfaz;

public class IUAdmin {

	public void clickCambiarEventos() {
		// TODO - implement IUAdmin.clickCambiarEventos
		throw new UnsupportedOperationException();
	}

}