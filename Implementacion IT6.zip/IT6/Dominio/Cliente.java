package Dominio;

public class Cliente {
	private String _dni;
	private String _nombre;
	private String _apellidos;
	private int _telefono;
	private Evento[] _eventos;
	private String _correoE;
	public Certificado _unnamed_Certificado_34;
	public Evento _unnamed_Evento_35;

	public void apuntarseEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void desapuntarseEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void a�adirEventoCalendario(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void pedirCertificado(int aIdCertificado) {
		throw new UnsupportedOperationException();
	}
}