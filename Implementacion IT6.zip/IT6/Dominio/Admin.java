package Dominio;

public class Admin extends Organizador {

	public void registrarEvento() {
		throw new UnsupportedOperationException();
	}

	public void editarEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void eliminarEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}
}