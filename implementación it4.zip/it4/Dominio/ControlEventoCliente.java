package Dominio;

public class ControlEventoCliente {

	public void apuntarseEvento() {
		// TODO - implement ControlEventoCliente.apuntarseEvento
		throw new UnsupportedOperationException();
	}

	public void desapuntarseEvento() {
		// TODO - implement ControlEventoCliente.desapuntarseEvento
		throw new UnsupportedOperationException();
	}

}