package Dominio;

public class ControlEvento {

	/**
	 * 
	 * @param IdEvento
	 */
	public void modificarEvento(int IdEvento) {
		// TODO - implement ControlEvento.modificarEvento
		throw new UnsupportedOperationException();
	}

	public void a�adirEvento() {
		// TODO - implement ControlEvento.a�adirEvento
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param IdEvento
	 */
	public void eliminarEvento(int IdEvento) {
		// TODO - implement ControlEvento.eliminarEvento
		throw new UnsupportedOperationException();
	}

}