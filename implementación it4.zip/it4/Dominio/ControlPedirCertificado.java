package Dominio;

public class ControlPedirCertificado {

	/**
	 * 
	 * @param IdCertificado
	 */
	public void pedirCertificado(int IdCertificado) {
		// TODO - implement ControlPedirCertificado.pedirCertificado
		throw new UnsupportedOperationException();
	}

}