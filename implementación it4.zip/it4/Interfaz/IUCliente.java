package Interfaz;

public class IUCliente {

	public void clickMisEventos() {
		// TODO - implement IUCliente.clickMisEventos
		throw new UnsupportedOperationException();
	}

}