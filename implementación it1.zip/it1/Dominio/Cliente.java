package Dominio;

public class Cliente {

	private string dni;
	private string nombre;
	private string apellidos;
	private int telefono;
	private string correoE;
	private Evento[] eventos;
}