package Interfaz;

public class IUCambiarEventos {

	public void mostrarFechasDisponibles() {
		throw new UnsupportedOperationException();
	}

	public void mostrarHorasYAulasLibres() {
		throw new UnsupportedOperationException();
	}

	public void mostrarMenu() {
		throw new UnsupportedOperationException();
	}
}