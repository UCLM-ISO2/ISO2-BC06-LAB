package Dominio;

public class Evento {
	private String _fecha;
	private String _aula;
	private String _hora;
	private int _id;
	public Cliente _unnamed_Cliente_15;
	public Certificado _unnamed_Certificado_16;
}