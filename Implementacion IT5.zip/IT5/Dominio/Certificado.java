package Dominio;

public class Certificado {
	private Cliente _cliente;
	private Evento _evento;
	private int _id;
	public Evento _unnamed_Evento_35;
	public Organizador _unnamed_Organizador_36;
	public Cliente _unnamed_Cliente_37;
}