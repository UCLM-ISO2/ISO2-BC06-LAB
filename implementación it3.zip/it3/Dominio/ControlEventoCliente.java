package Dominio;

public class ControlEventoCliente {

	public void apuntarseEvento() {
		// TODO - implement ControlEventoCliente.apuntarseEvento
		throw new UnsupportedOperationException();
	}

	public void desapuntarseEvento() {
		// TODO - implement ControlEventoCliente.desapuntarseEvento
		throw new UnsupportedOperationException();
	}

	public void generarQR() {
		// TODO - implement ControlEventoCliente.generarQR
		throw new UnsupportedOperationException();
	}

	public void usarGeolocalizacion() {
		// TODO - implement ControlEventoCliente.usarGeolocalizacion
		throw new UnsupportedOperationException();
	}

	public void abrirBluetooth() {
		// TODO - implement ControlEventoCliente.abrirBluetooth
		throw new UnsupportedOperationException();
	}

}