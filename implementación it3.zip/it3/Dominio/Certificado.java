package Dominio;

public class Certificado {

	private int Id;
	private Cliente cliente;
	private Evento evento;

}