package Dominio;

public class Evento {

	private string fecha;
	private string aula;
	private string hora;
	private int id;
	private boolean modadildad;
	private double codigoOnline;
	private boolean disponibilidad;

	public void generarQR() {
		// TODO - implement Evento.generarQR
		throw new UnsupportedOperationException();
	}

	public void usarGeolocalizacion() {
		// TODO - implement Evento.usarGeolocalizacion
		throw new UnsupportedOperationException();
	}

	public double getCodigoOnline() {
		return this.codigoOnline;
	}

}