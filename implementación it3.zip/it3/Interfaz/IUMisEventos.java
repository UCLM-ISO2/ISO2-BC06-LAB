package Interfaz;

public class IUMisEventos {

	public void apuntarse() {
		// TODO - implement IUMisEventos.apuntarse
		throw new UnsupportedOperationException();
	}

	public void desapuntarse() {
		// TODO - implement IUMisEventos.desapuntarse
		throw new UnsupportedOperationException();
	}

	public void mostrarQR() {
		// TODO - implement IUMisEventos.mostrarQR
		throw new UnsupportedOperationException();
	}

	public void usarGeolocalizacion() {
		// TODO - implement IUMisEventos.usarGeolocalizacion
		throw new UnsupportedOperationException();
	}

	public void abrirBluetooth() {
		// TODO - implement IUMisEventos.abrirBluetooth
		throw new UnsupportedOperationException();
	}

}