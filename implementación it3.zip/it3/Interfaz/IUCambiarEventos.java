package Interfaz;

public class IUCambiarEventos {

	public void mostrarFechasDisponibles() {
		// TODO - implement IUCambiarEventos.mostrarFechasDisponibles
		throw new UnsupportedOperationException();
	}

	public void mostrarHorasYAulasLibres() {
		// TODO - implement IUCambiarEventos.mostrarHorasYAulasLibres
		throw new UnsupportedOperationException();
	}

	public void mostrarMenu() {
		// TODO - implement IUCambiarEventos.mostrarMenu
		throw new UnsupportedOperationException();
	}

}