package Interfaz;

public class IUMisEventos {

	public void apuntarse() {
		// TODO - implement IUMisEventos.apuntarse
		throw new UnsupportedOperationException();
	}

	public void desapuntarse() {
		// TODO - implement IUMisEventos.desapuntarse
		throw new UnsupportedOperationException();
	}

}