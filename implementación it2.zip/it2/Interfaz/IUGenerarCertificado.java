package Interfaz;

public class IUGenerarCertificado {

	public void generarCertificado() {
		// TODO - implement IUGenerarCertificado.generarCertificado
		throw new UnsupportedOperationException();
	}

}