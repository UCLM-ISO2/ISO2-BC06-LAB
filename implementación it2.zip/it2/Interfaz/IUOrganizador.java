package Interfaz;

public class IUOrganizador {

	public void clickGenerarCertificado() {
		// TODO - implement IUOrganizador.clickGenerarCertificado
		throw new UnsupportedOperationException();
	}

}