package Dominio;

public class Evento {

	private string fecha;
	private string aula;
	private string hora;
	private int id;

}