package Dominio;

public class ControlGenCertificado {

	public void generarCertificado() {
		// TODO - implement ControlGenCertificado.generarCertificado
		throw new UnsupportedOperationException();
	}

}