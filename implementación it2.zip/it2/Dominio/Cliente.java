package Dominio;

public class Cliente {

	private string dni;
	private string nombre;
	private string apellidos;
	private int telefono;
	private string correoE;
	private Evento[] eventos;

	/**
	 * 
	 * @param IdEvento
	 */
	public void apuntarseEvento(int IdEvento) {
		// TODO - implement Cliente.apuntarseEvento
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param IdEvento
	 */
	public void desapuntarseEvento(int IdEvento) {
		// TODO - implement Cliente.desapuntarseEvento
		throw new UnsupportedOperationException();
	}

}