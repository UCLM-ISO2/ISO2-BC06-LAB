package Dominio;

public class Admin extends Organizador {

	public void registrarEvento() {
		// TODO - implement Admin.registrarEvento
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param IdEvento
	 */
	public void editarEvento(int IdEvento) {
		// TODO - implement Admin.editarEvento
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param IdEvento
	 */
	public void eliminarEvento(int IdEvento) {
		// TODO - implement Admin.eliminarEvento
		throw new UnsupportedOperationException();
	}

}