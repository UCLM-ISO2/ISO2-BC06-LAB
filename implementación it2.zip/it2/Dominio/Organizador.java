package Dominio;

public class Organizador {

	private string dni;
	private string nombre;
	private string apellidos;
	private int telefono;

	public void generarCertificado() {
		// TODO - implement Organizador.generarCertificado
		throw new UnsupportedOperationException();
	}

}