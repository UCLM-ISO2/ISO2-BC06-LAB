package Dominio;

public class Organizador {
	private String _dni;
	private String _nombre;
	private String _apellidos;
	private int _telefono;
	public Certificado _unnamed_Certificado_65;

	public void generarCertificado() {
		throw new UnsupportedOperationException();
	}
}