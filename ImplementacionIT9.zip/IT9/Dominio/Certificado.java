package Dominio;

public class Certificado {
	private Cliente _cliente;
	private Evento _evento;
	private int _id;
	public Evento _unnamed_Evento_62;
	public Organizador _unnamed_Organizador_63;
	public Cliente _unnamed_Cliente_64;
}