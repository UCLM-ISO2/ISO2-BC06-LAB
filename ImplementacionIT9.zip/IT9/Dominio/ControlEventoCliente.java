package Dominio;

public class ControlEventoCliente {

	public void apuntarseEvento() {
		throw new UnsupportedOperationException();
	}

	public void desapuntarseEvento() {
		throw new UnsupportedOperationException();
	}

	public void a�adirEventoCalendario(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void valorarEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}
}