package Dominio;

public class Evento {
	private String _fecha;
	private String _aula;
	private String _hora;
	private int _id;
	private boolean _disponibilidad;
	private String _tipo;
	public Cliente _unnamed_Cliente_53;
	public Certificado _unnamed_Certificado_54;
}