package Dominio;

public class ControlConsultasCliente {

	public void consultarDisponibilidad() {
		throw new UnsupportedOperationException();
	}

	public void consultarTipoEvento() {
		throw new UnsupportedOperationException();
	}

	public void consultarRangoFechas() {
		throw new UnsupportedOperationException();
	}
}