package Dominio;

public class Control_Evento {

	public void modificarEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}

	public void a�adirEvento() {
		throw new UnsupportedOperationException();
	}

	public void eliminarEvento(int aIdEvento) {
		throw new UnsupportedOperationException();
	}
}