package Interfaz;

public class IUCliente {

	public void clickMisEventos() {
		throw new UnsupportedOperationException();
	}
}