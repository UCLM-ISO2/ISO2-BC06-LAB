package Interfaz;

public class IUGenerarCertificado {

	public void generarCertificado() {
		throw new UnsupportedOperationException();
	}
}