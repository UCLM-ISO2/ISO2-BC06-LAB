package Interfaz;

public class IUAdmin {

	public void clickCambiarEventos() {
		throw new UnsupportedOperationException();
	}
}